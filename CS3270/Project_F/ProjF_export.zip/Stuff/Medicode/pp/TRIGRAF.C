/* trigraf.c:  Illustrate trigraph sequences */
 *
 *  NOTE:   DO NOT COMPILE! Preprocess only!
 */

#
[
]
^
{
|
}
~

