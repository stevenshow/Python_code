print "Hello, world"
